package com.watcher.ffplayer.entity;

import android.os.Environment;
public class Constant {
    public static String ip = "47.108.170.207";
    //public static String ip = "192.168.3.5";
    public static int portData = 7777;
    public static int portWarn = 7778;
    public static int portOther = 7779;
//    public static String SHARED_PREFERENCE_NAME = "CMPW DATA";
    public static int pullDuration = 1;
    public static double highTemp,highHumi;
    public static String wrongLight,wrongSmoke;
    public static String rootBase ,rootDir;
    public static String name,position;
    public static int wrongGLen = 1024*2;
    public static String boardType;
    public static String NA = "NA";
}

