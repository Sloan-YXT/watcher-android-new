package com.watcher.ffplayer.entity;

public class Graph {
    public String time;
}
