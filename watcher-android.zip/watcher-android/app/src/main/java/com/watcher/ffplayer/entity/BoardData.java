package com.watcher.ffplayer.entity;

public class BoardData {
    public String id;
    public String year;
    public String month;
    public String date;
    public String weekDay;
    public String time;
    public String boardName;
    public String boardLocation;
    public String temp;
    public String humi;
    public String light;
    public String smoke;
    public String action;
}
