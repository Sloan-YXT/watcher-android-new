package com.watcher.ffplayer.entity;

public class DataAlarm extends Alarm{
    public String temp,humi,light,smoke;
}
