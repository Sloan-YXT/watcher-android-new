package com.watcher.ffplayer;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import androidx.annotation.NonNull;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.watcher.ffplayer.entity.BoardData;
import com.watcher.ffplayer.entity.SocketStation;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.SocketException;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;

public class FlowChart extends Activity {
    private LineChart temp_chart,humi_chart;
    private BarChart action_chart_bar;
    private PieChart action_chart_pie;
    private List<BoardData> boardData = new ArrayList<BoardData>();
    String boardName;
    private Handler handler =  new Handler(Looper.myLooper())
    {
        @Override
        public void handleMessage(@NonNull Message msg) {
            switch (msg.what)
            {
                case 200:
                    temp_chart.setNoDataTextColor(Color.parseColor("#00bcef"));
                    List<Float> temps = new ArrayList<Float>();
                    List<Float> humis = new ArrayList<Float>();
                    List<String> actions = new ArrayList<String>();
                    List entries_temp = new ArrayList<>();
                    for(int i=0;i<boardData.size();i++)
                    {
                        temps.add(Float.parseFloat(boardData.get(i).temp));
                        humis.add(Float.parseFloat(boardData.get(i).humi));
                        actions.add(boardData.get(i).action);
                        entries_temp.add(new Entry(i,temps.get(i)));
                    }
                    LineDataSet lineDataSet = new LineDataSet(entries_temp,"temperature");
                    LineData lineData = new LineData(lineDataSet);
                    temp_chart.setData(lineData);
                    break;

                case 500:
                    Toast.makeText(FlowChart.this,"server shutdown!",Toast.LENGTH_SHORT).show();
                    try {
                        Thread.sleep(3000);
                    }
                    catch (Exception e)
                    {
                        Log.e("BoardDataActivity",Log.getStackTraceString(e));
                    }
                    SocketStation.exit();
                    break;
                default:
                    Toast.makeText(FlowChart.this,"数据请求失败！",Toast.LENGTH_SHORT).show();
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flow_chart);
        temp_chart = (LineChart) findViewById(R.id.temp_chart);
        temp_chart.setNoDataText("loading...");
        humi_chart = (LineChart) findViewById(R.id.humi_chart);
        humi_chart.setNoDataText("loading");
        action_chart_bar = (BarChart) findViewById(R.id.action_chart_bar);
        action_chart_bar.setNoDataText("loading");
        action_chart_pie = (PieChart) findViewById(R.id.action_chart_pie);
        action_chart_pie.setNoDataText("loading");
        Intent intent = getIntent();
        boardName = intent.getStringExtra("board name");
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    JSONObject mondData = new JSONObject();
                    mondData.put("type", "month data");
                    mondData.put("board name",boardName);
                    int len = mondData.toString().length();
                    OutputStream outOther = SocketStation.connfdOther.getOutputStream();
                    InputStream inOther = SocketStation.connfdOther.getInputStream();
                    byte[] len_aft = SocketStation.intToByte(len);
                    for(int i=0;i<4;i++)
                    {
                        outOther.write(len_aft[i]);
                    }
                    byte[] sendData = mondData.toString().getBytes();
                    for(int i=0;i<sendData.length;i++)
                    {
                        outOther.write(sendData[i]);
                    }
                    int [] len_pre = new int[4];
                    for(int i=0;i<4;i++)
                    {
                        len_pre[i] = inOther.read();
                        if(len_pre[i]==-1)
                        {
                            handler.sendEmptyMessage(500);
                            return;
                        }
                    }
                    len = SocketStation.byteToInt(len_pre);
                    byte[] data = new byte[len];
                    for(int i=0;i<len;i++)
                    {
                        data[i] = (byte)inOther.read();
                        if(data[i]==-1)
                        {
                            handler.sendEmptyMessage(500);
                            return;
                        }
                    }
                    String recvData = new String(data,"utf8");
                    JSONObject jRecvData = new JSONObject(recvData);
                    int num = jRecvData.getInt("num");
                    JSONArray nodes = jRecvData.getJSONArray("data");
                    Log.e("BoardDataActivity",recvData);
                    for(int i=0;i<num;i++)
                    {
                        JSONObject j = nodes.getJSONObject(i);
                        BoardData node = new BoardData();
                        node.id = j.getString("id");
                        node.year = j.getString("year");
                        node.weekDay = j.getString("weekday");
                        node.time = j.getString("time");
                        node.date = j.getString("date");
                        node.month = j.getString("month");
                        node.boardName = j.getString("name");
                        node.boardLocation = j.getString("location");
                        node.temp = j.getString("temp");
                        node.humi = j.getString("humi");
                        node.light = j.getString("light");
                        node.smoke = j.getString("smoke");
                        node.action = j.getString("action");
                        boardData.add(node);
                    }
                    Message msg = handler.obtainMessage();
                    msg.what = 200;
                    msg.obj = num;
                    handler.sendMessage(msg);
                }
                catch (SocketException e)
                {
                    Log.e("BoardDataActivity",Log.getStackTraceString(e));
                    handler.sendEmptyMessage(500);
                }
                catch (Exception e)
                {
                    Log.e("BoardDataActivity",Log.getStackTraceString(e));
                }

            }
        }).start();
    }
}