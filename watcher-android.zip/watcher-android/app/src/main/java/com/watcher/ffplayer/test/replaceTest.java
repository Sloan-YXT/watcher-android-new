package com.watcher.ffplayer.test;

public class replaceTest {
    public static void main(String[] args) {
        String a = "/sdcard/CMPW/Sun May 15 22:23:43 2022";
        System.out.printf(a.replace(" ","_"));
    }
}
