package com.watcher.ffplayer.entity;

import java.io.Serializable;

public class Board implements Serializable {
    public String boardName;
    public String boardLocation;
}
