package com.watcher.ffplayer.entity;

public class GraphAlarm extends Alarm{

}
